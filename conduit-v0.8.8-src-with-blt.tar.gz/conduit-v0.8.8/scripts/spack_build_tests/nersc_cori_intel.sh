python uberenv/uberenv.py --install --run_tests --spec="%intel~python" --spack-config-dir=uberenv/spack_configs/nersc/cori/ --prefix="_uberenv_test_cori_intel"


