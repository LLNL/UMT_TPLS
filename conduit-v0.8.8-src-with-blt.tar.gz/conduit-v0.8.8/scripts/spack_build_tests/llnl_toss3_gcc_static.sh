python uberenv/uberenv.py --install --run_tests --spec="%gcc~shared" --prefix="_uberenv_test_toss3_gcc_static"


