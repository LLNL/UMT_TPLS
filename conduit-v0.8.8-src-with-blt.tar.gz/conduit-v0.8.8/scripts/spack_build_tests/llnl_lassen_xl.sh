python uberenv/uberenv.py --install --run_tests --spec="%xl@coral~shared~python~fortran" --prefix="_uberenv_test_lassen_xl"


